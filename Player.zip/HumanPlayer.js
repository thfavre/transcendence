import Player from './Player.js';

export default class HumanPlayer extends Player {
	constructor(scene, physicsWorld, playerNb, startPos, endPos, fieldEdgeDiameter, upKeyCode, downKeyCode) {
		super(scene, physicsWorld, playerNb, startPos, endPos, fieldEdgeDiameter);
		this.upKeyCode = upKeyCode; // 87, 83 for w, s
		this.downKeyCode = downKeyCode;
	}

	setDownKeyCode(downKeyCode)
	{
		this.downKeyCode = downKeyCode;
	}

	setUpKeyCode(upKeyCode)
	{
		this.upKeyCode = upKeyCode;
	}

	movePaddle(keysdown)
	{
		if (keysdown.includes(this.upKeyCode))
			{this.paddle.moveUp();
		}
		if (keysdown.includes(this.downKeyCode))
			this.paddle.moveDown();
	}
}
